import {useState} from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import heroImg from './assets/hero.png'
import './App.css'
import ImageService from "./components/ImageService.jsx";

function App() {
    const [boardSize, setBoardSize] = useState(0)
    const [score, setScore] = useState(0)
    const [bestScore, setBestScore] = useState(0)
    const animalList = ["Lion", "zebra"]
    const animalListImage = animalList.map((animal) => {
            return <ImageService q={animal}/>;
        }
    )

    const updateBoardSize = (newSize) => {
        setBoardSize(newSize);
    }


    return (
        <div className='container'>
            {animalListImage}
        </div>

    )
}

export default App
