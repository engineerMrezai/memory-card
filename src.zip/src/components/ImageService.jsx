import { useEffect, useState } from "react";
import '../styles/ImageService.jsx.css'

function GifCard({ q }) {
    const apiKey = import.meta.env.VITE_GIPHY_API_KEY;

    const [gifUrl, setGifUrl] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!q) return;

        const fetchGif = async () => {
            try {
                setLoading(true);
                setError(null);

                const res = await fetch(
                    `https://api.giphy.com/v1/gifs/search?api_key=${apiKey}&q=${q}&limit=1`
                );

                if (!res.ok) {
                    throw new Error("Failed to fetch GIF");
                }

                const data = await res.json();

                const url = data?.data?.[0]?.images?.fixed_height?.url;

                setGifUrl(url || "");
            } catch (err) {
                setError(err.message);
                setGifUrl("");
            } finally {
                setLoading(false);
            }
        };

        fetchGif();
    }, [q, apiKey]);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return <img src={gifUrl} alt={q}/>;
}

export default function ({q}){
    return (
        <div className='box'>
            <div className="imageBox">
                <GifCard q={q}/>
            </div>
            <div className="contentBox">
                <p>{q.toUpperCase()}</p>
            </div>
        </div>
    )
}
